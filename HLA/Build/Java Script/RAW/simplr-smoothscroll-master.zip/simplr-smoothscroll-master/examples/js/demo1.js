
$(function () {
    $.srSmoothscroll();
});
